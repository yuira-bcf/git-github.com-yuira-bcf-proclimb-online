package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/crudapp")
public class CrudappController {

    @GetMapping
    public String index() {
        return "crudapp/index";
    }

    @GetMapping("/input")
    public String input() {
        return "crudapp/input";
    }

    @GetMapping("/confirm")
    public String confirm() {
        return "crudapp/confirm";
    }

    @PostMapping("/confirm")
    public String confirm(@RequestParam("content") String content, Model model) {
        model.addAttribute("content", content);
        return "crudapp/confirm";
    }

    @GetMapping("/complete")
    public String complete() {
        return "crudapp/complete";
    }

    @PostMapping("/complete")
    public String completePost() {
        return "crudapp/complete";
    }
}
