package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.mapper.NoteMapper;
import com.example.demo.model.Note;
import java.util.List;

@Controller
@RequestMapping("/crudapp")
public class CrudappController {

    private final NoteMapper noteMapper;

    public CrudappController(NoteMapper noteMapper) {
        this.noteMapper = noteMapper;
    }
    

    @GetMapping("/index")
    public String index(Model model) {
        List<Note> notes = noteMapper.findAll();
        model.addAttribute("notes", notes);
        return "crudapp/index";
    }



    @GetMapping("/input")
    public String input() {
        return "crudapp/input";
    }

    @GetMapping("/confirm")
    public String confirm() {
        return "crudapp/confirm";
    }

    @PostMapping("/confirm")
    public String confirm(@RequestParam("content") String content, Model model) {
        model.addAttribute("content", content);
        return "crudapp/confirm";
    }

    @GetMapping("/complete")
    public String complete() {
        return "crudapp/complete";
    }

    @PostMapping("/complete")
    public String completePost(@RequestParam("content") String content) {
          noteMapper.insert(content);
          return "redirect:/crudapp/index"; 
    }

    @GetMapping("/edit")
    public String edit(@RequestParam("id") Long id, Model model) {
    Note note = noteMapper.findById(id);
    model.addAttribute("note", note);
    return "crudapp/edit";
    }

    @PostMapping("/edit")
    public String update(@RequestParam("id") Long id, @RequestParam("content") String content) {

    Note note = new Note();
    note.setId(id);
    note.setText(content);
    noteMapper.update(note);
    return "redirect:/crudapp/index";
    }

    @GetMapping("/test")
    @ResponseBody
    public String test() {
        int count = noteMapper.count();
        return "データ件数: " + count;
    }

}
