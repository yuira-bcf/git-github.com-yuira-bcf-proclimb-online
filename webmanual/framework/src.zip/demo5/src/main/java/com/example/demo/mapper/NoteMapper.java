package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.model.Note;

@Mapper
public interface NoteMapper {
int count();
List<Note> findAll();
int insert(String text);
Note findById(Long id);
int update(Note note);
}