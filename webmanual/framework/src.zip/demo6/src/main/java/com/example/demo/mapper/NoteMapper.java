package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.model.Note;

@Mapper
public interface NoteMapper {
int count();
List<Note> findAll();
int insert(String text);
Note findById(Long id);
int update(Note note);
int softDelete(Long id);
 int toggleVisibility(@Param("id") Long id, @Param("isVisible") Integer isVisible);

}