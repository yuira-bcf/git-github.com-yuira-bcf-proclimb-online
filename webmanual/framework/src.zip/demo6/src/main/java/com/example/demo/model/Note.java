package com.example.demo.model;
import java.time.LocalDateTime;
public class Note {
    private Long id;
    private String text;
    private LocalDateTime createdAt;
    private Integer isDeleted;
    private Integer isVisible;


    public Long getId() {
     return id;
    }
        public void setId(Long id) {
        this.id = id;
    }
    public String getText() {
    return text;
    }

    public void setText(String text) {
    this.text = text;
    }

    public LocalDateTime getCreatedAt() {
    return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
    this.createdAt = createdAt;
    }

    public Integer getIsDeleted() {
    return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Integer getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(Integer isVisible) {
        this.isVisible = isVisible;
    }

}