public class Hero extends Character {
    private final int strength;

    public Hero(String name, int hp, int strength) {
        super(name, hp);
        this.strength = strength;
    }

    @Override
    public void attack(Matango m) {
        int damage = this.strength;
        System.out.println(this.name + " attacks! damage=" + damage);
        m.hp -= damage;
        if (m.hp < 0) {
            m.hp = 0;
        }
    }
}
