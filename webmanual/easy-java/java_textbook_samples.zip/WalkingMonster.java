public abstract class WalkingMonster extends Monster {
    public WalkingMonster(String name, int hp, int mp) {
        super(name, hp, mp);
    }

    @Override
    public void run() {
        System.out.println(this.name + " runs away on foot.");
    }

    // attack() is still abstract here.
}
