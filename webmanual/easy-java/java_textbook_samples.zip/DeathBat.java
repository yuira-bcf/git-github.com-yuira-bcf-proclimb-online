public class DeathBat extends FlyingMonster {
    public DeathBat(String name, int hp, int mp) {
        super(name, hp, mp);
    }

    @Override
    public void attack() {
        System.out.println(this.name + " attacks by pecking.");
    }
}
