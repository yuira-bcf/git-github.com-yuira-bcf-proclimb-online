public interface HeroRole {
    void run();
}
