public abstract class FlyingMonster extends Monster {
    public FlyingMonster(String name, int hp, int mp) {
        super(name, hp, mp);
    }

    @Override
    public void run() {
        System.out.println(this.name + " flies away.");
    }

    // attack() is still abstract here.
}
