public class Fool extends Character implements Human {
    public Fool(String name, int hp) {
        super(name, hp);
    }

    @Override
    public void attack(Matango m) {
        int damage = 1;
        System.out.println(this.name + " attacks softly. damage=" + damage);
        m.hp -= damage;
        if (m.hp < 0) {
            m.hp = 0;
        }
    }

    @Override
    public void talk() {
        System.out.println(this.name + " talks.");
    }

    @Override
    public void watch() {
        System.out.println(this.name + " watches.");
    }

    @Override
    public void hear() {
        System.out.println(this.name + " hears.");
    }

    // run() is already provided by Character.
    // Because Character.run() is public and has the same signature,
    // it satisfies Creature.run() required by Human.
}
