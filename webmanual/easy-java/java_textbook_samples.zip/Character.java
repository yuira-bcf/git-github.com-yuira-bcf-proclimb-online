public abstract class Character {
    protected final String name;
    protected int hp;

    public Character(String name, int hp) {
        this.name = name;
        this.hp = hp;
    }

    public String getName() {
        return name;
    }

    public int getHp() {
        return hp;
    }

    // Concrete method: shared behavior
    public void run() {
        System.out.println(this.name + " runs away.");
    }

    // Abstract method: must be implemented by subclasses
    public abstract void attack(Matango m);
}
