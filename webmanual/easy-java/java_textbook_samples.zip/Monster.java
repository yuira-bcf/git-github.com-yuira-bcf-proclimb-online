public abstract class Monster {
    protected final String name;
    protected int hp;
    protected int mp;

    public Monster(String name, int hp, int mp) {
        this.name = name;
        this.hp = hp;
        this.mp = mp;
    }

    public String status() {
        return this.name + " (hp=" + this.hp + ", mp=" + this.mp + ")";
    }

    public abstract void attack();

    public abstract void run();
}
