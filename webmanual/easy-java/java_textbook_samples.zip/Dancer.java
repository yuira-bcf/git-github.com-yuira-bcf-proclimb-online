public class Dancer extends Character {
    public Dancer(String name, int hp) {
        super(name, hp);
    }

    public void dance() {
        System.out.println(this.name + " dances.");
    }

    @Override
    public void attack(Matango m) {
        int damage = 3;
        System.out.println(this.name + " attacks with rhythm! damage=" + damage);
        m.hp -= damage;
        if (m.hp < 0) {
            m.hp = 0;
        }
    }
}
