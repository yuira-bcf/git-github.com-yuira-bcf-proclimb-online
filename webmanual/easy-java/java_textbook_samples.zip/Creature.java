public interface Creature {
    void run();
}
