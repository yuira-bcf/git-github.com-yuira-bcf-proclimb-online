public class Main {
    public static void main(String[] args) {
        System.out.println("== Demo 1: Abstract class + abstract method ==");
        demoAbstractClass();

        System.out.println();
        System.out.println("== Demo 2: Multi-level abstract inheritance ==");
        demoMultiLevelAbstractInheritance();

        System.out.println();
        System.out.println("== Demo 3: Interface + implements (and extends) ==");
        demoInterfaces();

        System.out.println();
        System.out.println("== Demo 4: Multiple interfaces (diamond-safe) ==");
        demoMultipleInterfaces();

        System.out.println();
        System.out.println("== Demo 5: Interface constants ==");
        demoInterfaceConstants();
    }

    private static void demoAbstractClass() {
        Matango m = new Matango("A", 20);

        Character hero = new Hero("Minato", 30, 10);
        Character wizard = new Wizard("Suga", 25, 5);
        Character dancer = new Dancer("Yui", 18);

        System.out.println("Enemy: " + m.getName() + " (hp=" + m.hp + ")");

        hero.attack(m);
        wizard.attack(m);
        dancer.attack(m);

        System.out.println("Enemy hp after attacks: " + m.hp);

        hero.run();

        // NOTE:
        // The following line would NOT compile because Character is abstract.
        // Character c = new Character("X", 1);
    }

    private static void demoMultiLevelAbstractInheritance() {
        Monster goblin = new Goblin("Goblin", 12, 3);
        Monster deathBat = new DeathBat("DeathBat", 8, 10);

        System.out.println(goblin.status());
        goblin.run();
        goblin.attack();

        System.out.println(deathBat.status());
        deathBat.run();
        deathBat.attack();
    }

    private static void demoInterfaces() {
        Fool f = new Fool("Fool", 15);

        // From Character
        f.run();

        // From Human (interface)
        f.talk();
        f.watch();
        f.hear();

        // From Character (abstract method implemented by Fool)
        Matango m = new Matango("B", 7);
        f.attack(m);
        System.out.println("Enemy hp after Fool attack: " + m.hp);
    }

    private static void demoMultipleInterfaces() {
        PrincessHero ph = new PrincessHero();

        HeroRole asHero = ph;
        PrincessRole asPrincess = ph;

        asHero.run();
        asPrincess.run();
    }

    private static void demoInterfaceConstants() {
        double radius = 2.0;
        double area = Circle.PI * radius * radius;
        System.out.println("PI=" + Circle.PI);
        System.out.println("area(r=2.0)=" + area);
    }
}
