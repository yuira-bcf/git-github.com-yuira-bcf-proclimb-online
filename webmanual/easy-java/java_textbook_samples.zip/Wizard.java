public class Wizard extends Character {
    private final int magicPower;

    public Wizard(String name, int hp, int magicPower) {
        super(name, hp);
        this.magicPower = magicPower;
    }

    @Override
    public void attack(Matango m) {
        int damage = this.magicPower;
        System.out.println(this.name + " casts a spell! damage=" + damage);
        m.hp -= damage;
        if (m.hp < 0) {
            m.hp = 0;
        }
    }
}
