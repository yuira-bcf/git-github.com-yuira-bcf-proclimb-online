public interface Circle {
    // Fields in an interface are implicitly: public static final
    double PI = 3.141592;
}
