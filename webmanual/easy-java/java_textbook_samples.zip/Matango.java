public class Matango {
    private final String suffix;
    public int hp;

    public Matango(String suffix, int hp) {
        this.suffix = suffix;
        this.hp = hp;
    }

    public String getName() {
        return "Matango" + suffix;
    }
}
