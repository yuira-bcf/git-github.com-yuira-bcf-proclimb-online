public interface PrincessRole {
    void run();
}
