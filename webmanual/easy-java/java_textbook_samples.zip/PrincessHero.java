public class PrincessHero implements HeroRole, PrincessRole {
    @Override
    public void run() {
        System.out.println("PrincessHero runs with two roles.");
    }
}
