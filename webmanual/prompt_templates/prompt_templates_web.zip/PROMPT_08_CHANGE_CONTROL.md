# PROMPT_08_CHANGE_CONTROL：変更管理（Change Control）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 差分・理由・影響範囲・再テストを揃えて安全に改修する |
| 使うタイミング | フェーズ：PROMPT_08_CHANGE_CONTROL |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md)
- ▶ 次：[`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは実装担当です。以下の変更指示に従って修正してください。
基本ルール（PROMPT_00）に従い、変更理由と影響範囲も説明してください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 「直して」ではなく、差分・理由・影響範囲で安全に改修します。

【変更指示（埋めてください）】
- 変更目的：<< >>
- 変更内容（Before/After）：<< >>
- 変更対象ファイル：<< >>
- 変更禁止事項（触らない部分）：<< >>
- 期待する挙動（受入条件）：<< >>
- 追加/更新したいテスト：<< >>

【入力（埋めてください）】
- 現在のコード：<< >>
- 現在の要件（必要なら）：<< >>

【あなたへの指示】
1) 変更点を整理して「修正計画（短く）」を出してください。
2) 次に修正版コードをファイル単位で提示してください（変更がないファイルは省略可）。
3) 変更理由、影響範囲、再テスト項目を明記してください。
4) 仕様や基本ルールに反する変更はしないでください（必要なら要確認として止める）。

【出力形式】
- 修正計画
- 修正版コード（ファイル単位）
- 変更理由 / 影響範囲 / 再テスト項目
- 要確認（あれば）
```

---

## このテンプレのリンク

- このページ（PROMPT_08_CHANGE_CONTROL.md）：[PROMPT_08_CHANGE_CONTROL.md](PROMPT_08_CHANGE_CONTROL.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
