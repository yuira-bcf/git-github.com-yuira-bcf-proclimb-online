# PROMPT_06_VERIFICATION：検証（Verification）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 受入条件を満たすか確認できるテスト観点・手順・ケースを作る |
| 使うタイミング | フェーズ：PROMPT_06_VERIFICATION |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md)
- ▶ 次：[`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたはテスト設計担当です。要件と実装を前提に、検証手順を作成します。
基本ルール（PROMPT_00）と要件（PROMPT_02）に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 受入条件を満たすかを確認できる手順・ケースを作ります。

【入力（埋めてください）】
- 要件定義（Acceptance Criteria含む）：<< >>
- 実装コード（貼れる範囲でOK）：<< >>
- 実行形態：<<例：コンソール>>

【あなたへの指示】
1) テスト観点を列挙してください（機能/入力異常/境界/表示/状態など）。
2) 手動テスト手順を「操作→期待結果」で書いてください。
3) テストケースを表形式（ID、前提、入力、期待結果、備考）で10〜20件作ってください。
4) 受入条件とテストケースの対応を確認し、抜けがあれば追加してください。

【出力形式】
- テスト観点一覧
- 手動テスト手順
- テストケース一覧（表）
- 受入条件→テスト対応チェック
```

---

## このテンプレのリンク

- このページ（PROMPT_06_VERIFICATION.md）：[PROMPT_06_VERIFICATION.md](PROMPT_06_VERIFICATION.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
