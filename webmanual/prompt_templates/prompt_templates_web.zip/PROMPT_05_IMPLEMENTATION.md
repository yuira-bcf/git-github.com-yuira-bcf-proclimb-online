# PROMPT_05_IMPLEMENTATION：実装生成（Implementation）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 設計に沿ったコード一式をファイル単位で生成する |
| 使うタイミング | フェーズ：PROMPT_05_IMPLEMENTATION |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md)
- ▶ 次：[`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは開発支援AIです。確定した設計に基づき実装を生成します。
基本ルール（PROMPT_00）と設計（PROMPT_04）に厳密に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 設計に沿ったコード一式を、ファイル単位で生成します。

【入力（埋めてください）】
- 設計（クラス構成・責務・メソッド）：<< >>
- 実行形態：<<例：コンソール>>
- 永続化：<<例：なし / CSV保存>>

【あなたへの指示】
1) ファイル構成を最初に提示してください（例：Main.java, Game.java...）。
2) 次に、各ファイルを「ファイル名 → コード全文」で順に出してください（省略禁止）。
3) 入力バリデーションと再入力は必須です。
4) 実行手順（コンパイル/実行コマンド）を最後に書いてください。
5) 外部依存（DB/Web/外部API）は使わないでください。

【出力形式】
- ファイル構成
- 各ファイル：ファイル名 → コード全文
- 実行手順
```

---

## このテンプレのリンク

- このページ（PROMPT_05_IMPLEMENTATION.md）：[PROMPT_05_IMPLEMENTATION.md](PROMPT_05_IMPLEMENTATION.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
