# PROMPT_00_BASELINE：基本ルール固定（Baseline）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 以後の全工程に適用する“ルール・制約・出力形式”を固定する |
| 使うタイミング | フェーズ：PROMPT_00_BASELINE |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：なし
- ▶ 次：[`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは開発支援AIです。これから「プロンプトプログラミング」で開発を進めます。
以下の基本ルールは、以後の全工程に適用します。矛盾がないように整理し、最終版を出力してください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 基本ルール（禁止事項・制約・出力形式・品質基準）を固定して、以後の出力ブレを防ぎます。

【前提（あなたの役割）】
- 私はコードを直接編集しません（必要なら修正指示を出します）。
- あなたは設計・実装・テスト観点・修正案を生成します。

【基本ルール（埋めてください）】
- 使用言語：<<例：Java>>
- 想定レベル：<<例：Bronze範囲>>
- 禁止事項：
  - <<例：DB使用禁止 / Web使用禁止 / 外部API禁止 / ネットワーク通信禁止>>
- 許可事項：
  - <<例：標準ライブラリのみ / ファイル保存は許可 など>>
- 出力形式：
  - <<例：ファイル単位で「ファイル名 → コード全文」>>
  - <<例：コードは省略しない>>
- 品質基準：
  - <<例：入力バリデーション必須 / 例外で即終了しない / 再入力誘導>>
- 命名・スタイル：
  - <<例：クラスはUpperCamel / メソッドはlowerCamel / コメント最小>>
- 実行環境：
  - <<例：コンソール / Java 17>>

【あなたへの指示】
1) 上記を「基本ルールプロンプト（最終版）」として読みやすく整形してください。
2) 矛盾や不足があれば「矛盾/不足リスト」を出してください（推測で勝手に補完しない）。
3) 最後に「この基本ルールを以後の工程で参照します」と明記してください。

【出力形式】
- セクション1：基本ルールプロンプト（最終版）
- セクション2：矛盾/不足リスト（あれば）
```

---

## このテンプレのリンク

- このページ（PROMPT_00_BASELINE.md）：[PROMPT_00_BASELINE.md](PROMPT_00_BASELINE.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
