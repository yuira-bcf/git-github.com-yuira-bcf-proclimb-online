# PROMPT_09_ASSETIZATION：資産化（Assetization）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 再現可能な“開発資産”としてプロンプト・成果物を保存する |
| 使うタイミング | フェーズ：PROMPT_09_ASSETIZATION |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md)
- ▶ 次：なし
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたはドキュメント担当です。ここまでの成果物を「再現できる開発資産」にまとめます。
基本ルール（PROMPT_00）に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 会話を終わらせず、次回も同じ型で回せるように資産化します。

【入力（埋めてください）】
- 基本ルール：<< >>
- スコープ：<< >>
- 要件定義：<< >>
- 仮定/未決定：<< >>
- 設計：<< >>
- 実装：<< >>
- テスト：<< >>
- 変更履歴：<< >>

【あなたへの指示】
1) 以下のファイル構成で「保存すべき内容」を整形してください。
2) README（概要、実行方法、仕様、制約、テスト方法）を作ってください。
3) CHANGELOG（変更理由・影響範囲・対応テスト）を整理してください。
4) 最後に「次回このプロジェクトを再開するための手順」を短く書いてください。

【出力形式（提案）】
- PROMPT_00_BASELINE.md
- PROMPT_01_SCOPE.md
- PROMPT_02_REQUIREMENTS.md
- PROMPT_03_ASSUMPTIONS.md
- PROMPT_04_DESIGN.md
- PROMPT_05_IMPLEMENTATION.md
- PROMPT_06_VERIFICATION.md
- PROMPT_07_REVIEW.md
- PROMPT_08_CHANGE_CONTROL.md
- PROMPT_09_ASSETIZATION.md
- README.md
- CHANGELOG.md
```

---

## このテンプレのリンク

- このページ（PROMPT_09_ASSETIZATION.md）：[PROMPT_09_ASSETIZATION.md](PROMPT_09_ASSETIZATION.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
