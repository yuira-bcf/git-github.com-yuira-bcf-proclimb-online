# PROMPT_02_REQUIREMENTS：要件定義（Requirements）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 機能/非機能/入出力/受入条件をテスト可能な粒度で固める |
| 使うタイミング | フェーズ：PROMPT_02_REQUIREMENTS |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md)
- ▶ 次：[`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは開発支援AIです。以下の情報から要件定義を作成します。
基本ルール（PROMPT_00）とスコープ（PROMPT_01）に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 実装が迷わない粒度で「機能要件/非機能要件/入出力/例外時」を文章化します。

【入力（埋めてください）】
- 作りたい機能（箇条書き）：<< >>
- 画面・操作（コンソールならメニュー遷移）：<< >>
- 入力形式：<<例：g/c/p、数字メニューなど>>
- 出力形式：<<例：結果文言、一覧表示>>
- 永続化：<<例：なし / ファイル保存あり（CSV）>>
- 例外・不正入力：<<例：再入力させる、エラーメッセージ>>

【あなたへの指示】
1) 機能要件（FR）を番号付きで整理してください。
2) 非機能要件（NFR：品質/制約/運用）を整理してください。
3) 入力仕様（許容/禁止/再入力）と出力仕様（表示項目）を明文化してください。
4) 受入条件（Acceptance Criteria）を「テスト可能な文」で5〜10個作ってください。
5) 曖昧な点は「要確認」に分離してください（推測で埋めない）。

【出力形式】
- 機能要件（FR）
- 非機能要件（NFR）
- 入力仕様 / 出力仕様
- 受入条件（Acceptance Criteria）
- 要確認リスト（あれば）
```

---

## このテンプレのリンク

- このページ（PROMPT_02_REQUIREMENTS.md）：[PROMPT_02_REQUIREMENTS.md](PROMPT_02_REQUIREMENTS.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
