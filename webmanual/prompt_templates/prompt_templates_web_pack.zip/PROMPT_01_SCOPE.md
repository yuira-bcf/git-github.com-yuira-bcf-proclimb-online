# PROMPT_01_SCOPE：目的・範囲の確定（Scope）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 何を作る/作らない（in/out）を確定する |
| 使うタイミング | フェーズ：PROMPT_01_SCOPE |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md)
- ▶ 次：[`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは開発支援AIです。以下の情報から、成果物の目的とスコープ（in/out）を確定します。
基本ルールは別紙（PROMPT_00_BASELINE）に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 「何を作る/作らない」を固定して、後工程の迷走を防ぎます。

【成果物の概要（埋めてください）】
- アプリ名：<< >>
- 目的：<< >>
- 想定ユーザー：<< >>
- 実行形態：<<例：コンソール / Swing>>
- 利用シーン：<< >>

【スコープ候補（埋めてください）】
- In scope（作ること）：
  - <<例：メニュー / 入力 / 結果表示 / 戦績表示>>
- Out of scope（作らないこと）：
  - <<例：ネット対戦 / オンラインランキング / 画像演出>>

【あなたへの指示】
1) 上記を整理して「スコープ定義（最終版）」を作ってください。
2) In/Outの境界が曖昧な点があれば「要確認」にして列挙してください（勝手に決めない）。
3) 最後に「完成の定義（Done）」を1〜3行で書いてください。

【出力形式】
- スコープ定義（最終版）
- 要確認リスト（あれば）
- 完成の定義（Done）
```

---

## このテンプレのリンク

- このページ（PROMPT_01_SCOPE.md）：[PROMPT_01_SCOPE.md](PROMPT_01_SCOPE.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
