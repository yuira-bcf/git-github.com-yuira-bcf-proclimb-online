# プロンプトテンプレート一覧

> 🌐 **Web掲載用**：このページは“入口”です。  
> 下の表から順番に進めれば、プロンプトプログラミングが **迷子になりにくい** です（迷子になるのは人間で、AIではありません。たぶん）。

---

## ダウンロード

- 📦 テンプレ一式（ZIP）：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## 使い方（最短）

1. **`PROMPT_00_BASELINE`** で「禁止事項・制約・出力形式」を固定  
2. **`PROMPT_01_SCOPE`** で「作る/作らない」を確定  
3. **`PROMPT_02_REQUIREMENTS`** で受入条件まで落とす  
4. **`PROMPT_03_ASSUMPTIONS`** で“未確定”と“仮定”を分離（勝手補完を殺す）  
5. **`PROMPT_04_DESIGN`** → **`05_IMPLEMENTATION`** で設計→実装  
6. **`PROMPT_06_VERIFICATION`** → **`07_REVIEW`** で検証→改善  
7. 修正は **`PROMPT_08_CHANGE_CONTROL`**（差分・理由・影響範囲）  
8. 最後に **`PROMPT_09_ASSETIZATION`** で資産化

---

## テンプレ一覧（Phase順）

| Phase | テンプレ | 名前 | 目的 |
|---:|---|---|---|
| 1 | [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) | 基本ルール固定（Baseline） | 以後の全工程に適用する“ルール・制約・出力形式”を固定する |
| 2 | [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) | 目的・範囲の確定（Scope） | 何を作る/作らない（in/out）を確定する |
| 3 | [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) | 要件定義（Requirements） | 機能/非機能/入出力/受入条件をテスト可能な粒度で固める |
| 4 | [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) | 仮定と未決定事項の固定（Assumptions） | 仕様の空白を“仮定/未決定”として分離し、勝手補完を防ぐ |
| 5 | [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) | 設計（Design） | 責務分割・データ構造・処理フローを固めてから実装に入る |
| 6 | [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) | 実装生成（Implementation） | 設計に沿ったコード一式をファイル単位で生成する |
| 7 | [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) | 検証（Verification） | 受入条件を満たすか確認できるテスト観点・手順・ケースを作る |
| 8 | [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) | レビューと改善（Review） | 仕様ズレ/入力/例外/保守性の穴を洗い出し、Change Requestに落とす |
| 9 | [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) | 変更管理（Change Control） | 差分・理由・影響範囲・再テストを揃えて安全に改修する |
| 10 | [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) | 資産化（Assetization） | 再現可能な“開発資産”としてプロンプト・成果物を保存する |

---

## コツ（地味に効くやつ）

- **「不明点は推測しない」** を守る（AIの推測はだいたい“それっぽい事故”になる）  
- **受入条件を先に決める**（後から決めると、だいたい地獄）  
- 修正依頼は「直して」ではなく **Before/After**（人間もAIもこれで平和になる）
