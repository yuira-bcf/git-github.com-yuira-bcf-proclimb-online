# PROMPT_04_DESIGN：設計（Design）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 責務分割・データ構造・処理フローを固めてから実装に入る |
| 使うタイミング | フェーズ：PROMPT_04_DESIGN |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md)
- ▶ 次：[`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは開発支援AIです。以下の情報を前提に設計を作成します。
基本ルール（PROMPT_00）、要件（PROMPT_02）、仮定（PROMPT_03）に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- コード生成の前に、構造（責務分割・データ構造・処理フロー）を固めます。

【入力（埋めてください）】
- 要件定義：<< >>
- 確定した仮定（Assumptionsの中で採用したもの）：<< >>

【あなたへの指示】
1) モジュール/クラス一覧を作り、各責務を1〜3行で説明してください。
2) 主要メソッド一覧（引数・戻り値・例外方針も簡単に）を出してください。
3) データ構造（List/Map/配列など）と理由を書いてください。
4) 主要な処理フロー（メニュー→入力→判定→表示など）を手順で書いてください。
5) 「要件→設計対応表」を作り、要件の抜けがないか自己チェックしてください。
6) 最後に、実装生成に入る前の「確認ポイント」を列挙してください。

【出力形式】
- クラス/モジュール設計
- 主要メソッド設計
- データ構造
- 処理フロー
- 要件→設計対応（抜けチェック）
- 実装前確認ポイント
```

---

## このテンプレのリンク

- このページ（PROMPT_04_DESIGN.md）：[PROMPT_04_DESIGN.md](PROMPT_04_DESIGN.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
