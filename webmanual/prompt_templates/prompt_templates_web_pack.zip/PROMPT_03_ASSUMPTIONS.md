# PROMPT_03_ASSUMPTIONS：仮定と未決定事項の固定（Assumptions）

> 🌐 **Web掲載用**：このページは「読める」＋「コピペで使える」を両立する形に整形しています。  
> 使うのは下の **「コピペ用テンプレート」** だけ。上は説明、下が実戦。  

---

## 概要

| 項目 | 内容 |
|---|---|
| 目的 | 仕様の空白を“仮定/未決定”として分離し、勝手補完を防ぐ |
| 使うタイミング | フェーズ：PROMPT_03_ASSUMPTIONS |
| 入力 | `<< >>` を埋めて貼る（不明点は *要確認* として残す） |
| 出力 | 指定のフォーマットで“省略なし” |

---

## ナビゲーション

- 🏠 一覧：[`PROMPT_INDEX`](PROMPT_INDEX.md)
- ◀ 前：[`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md)
- ▶ 次：[`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md)
- 📦 ZIP：[`prompt_templates_web.zip`](prompt_templates_web.zip)

---

## テンプレート一覧

<details>
<summary>クリックで開く（全10テンプレ）</summary>

- [`PROMPT_00_BASELINE`](PROMPT_00_BASELINE.md) — 基本ルール固定（Baseline）
- [`PROMPT_01_SCOPE`](PROMPT_01_SCOPE.md) — 目的・範囲の確定（Scope）
- [`PROMPT_02_REQUIREMENTS`](PROMPT_02_REQUIREMENTS.md) — 要件定義（Requirements）
- [`PROMPT_03_ASSUMPTIONS`](PROMPT_03_ASSUMPTIONS.md) — 仮定と未決定事項の固定（Assumptions）
- [`PROMPT_04_DESIGN`](PROMPT_04_DESIGN.md) — 設計（Design）
- [`PROMPT_05_IMPLEMENTATION`](PROMPT_05_IMPLEMENTATION.md) — 実装生成（Implementation）
- [`PROMPT_06_VERIFICATION`](PROMPT_06_VERIFICATION.md) — 検証（Verification）
- [`PROMPT_07_REVIEW`](PROMPT_07_REVIEW.md) — レビューと改善（Review）
- [`PROMPT_08_CHANGE_CONTROL`](PROMPT_08_CHANGE_CONTROL.md) — 変更管理（Change Control）
- [`PROMPT_09_ASSETIZATION`](PROMPT_09_ASSETIZATION.md) — 資産化（Assetization）

</details>

---

## コピペ用テンプレート

> ✅ **ここだけコピーして使う**（`<< >>` を埋める）

```text
あなたは開発支援AIです。要件定義を読んだ上で、仮定と未決定事項を整理します。
基本ルール（PROMPT_00）と要件定義（PROMPT_02）に従ってください。

基本ルール（PROMPT_00_BASELINE）に厳密に従ってください。
不明点は推測で埋めず、「要確認」として止めてください。
出力は指定フォーマットに従い、省略しないでください。

【目的】
- 仕様の空白をAIが勝手に補完してブレるのを防ぎます。

【入力（埋めてください）】
- 要件定義（貼り付け or 箇条書き）：<< >>

【あなたへの指示】
1) 要件定義から、仕様が未確定な点を抽出して「未決定事項（Open Issues）」に列挙してください。
2) 仕様の空白を埋める必要がある点は「仮定（Assumptions）」として提案してください。
3) 仮定は、できれば「選択肢A/B」とそれぞれのメリット・デメリットを付けてください。
4) 最後に「推奨案」を出してください。ただし決定は私がします（勝手に確定しない）。

【出力形式】
- 未決定事項（Open Issues）
- 仮定案（Assumptions：選択肢付き）
- 推奨案（理由付き）
```

---

## このテンプレのリンク

- このページ（PROMPT_03_ASSUMPTIONS.md）：[PROMPT_03_ASSUMPTIONS.md](PROMPT_03_ASSUMPTIONS.md)
- テンプレ一覧：[`PROMPT_INDEX.md`](PROMPT_INDEX.md)
- ZIPダウンロード：[`prompt_templates_web_pack.zip`](prompt_templates_web_pack.zip)
